
//import Frame.AddEmp;
//import Frame.Registration;
import Frame.Hotel;
//import Frame.Login;
import Frame.Registration;
//import Frame.AddDriver;
import Frame.AddRooms;
import Frame.AddCustomer;
//import Frame.Dashboard;
//import Frame.Reception;

public class Main {
    public static void main(String[] args) {
        //new Hotel();
        //new Dashboard();
        //new Login();*/
        //new Registration();
       // new AddEmp();
       new AddRooms();
       //new AddDriver();
       //new Reception();
       //new AddCustomer();
    }
    
}
